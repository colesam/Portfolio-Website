<!DOCTYPE HTML>

<html>
    <head>
        <title>Samuel Cole</title>

        <!-- stylesheets -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/index.css">

        <!-- google fonts -->
        <link href="https://fonts.googleapis.com/css?family=Noto+Sans|Playfair+Display:700" rel="stylesheet"> 

        <!-- meta data -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">

        <!--[if IE]>
            <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        

    </head>
<body>